python fetch_news.py
python analyze_sentiment.py
python ./prediction/historical_data.py
python ./prediction/prepare_data.py
python ./prediction/train_model.py
pythom ./prediction/predict.py
python  trading_decision.py